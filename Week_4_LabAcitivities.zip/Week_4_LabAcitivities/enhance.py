from PIL import Image, ImageEnhance

# import an image 
image = Image.open('1_Gammar 2021_1_2021_06_03-13-19-23-879.PNG')

# create an enhancer
vibrance_enhancer = ImageEnhance.Color(image)
contrast_enhancer = ImageEnhance.Contrast(image)
brightness_enhancer = ImageEnhance.Brightness(image)
sharpness_enhancer = ImageEnhance.Sharpness(image)

# apply the enhancer 
enhanced_image = sharpness_enhancer.enhance(1.5)

# show 
image.show()
enhanced_image.show()

image = Image.open('1_Limniu 2021_1_2021_06_02-13-08-37-958.PNG')

# create an enhancer
vibrance_enhancer = ImageEnhance.Color(image)
contrast_enhancer = ImageEnhance.Contrast(image)
brightness_enhancer = ImageEnhance.Brightness(image)
sharpness_enhancer = ImageEnhance.Sharpness(image)

# apply the enhancer 
enhanced_image = sharpness_enhancer.enhance(1.5)

# show 
image.show()
enhanced_image.show()


image = Image.open('2_Sphaer 2021_1_2021_06_03-11-22-54-894.PNG')

# create an enhancer
vibrance_enhancer = ImageEnhance.Color(image)
contrast_enhancer = ImageEnhance.Contrast(image)
brightness_enhancer = ImageEnhance.Brightness(image)
sharpness_enhancer = ImageEnhance.Sharpness(image)

# apply the enhancer 
enhanced_image = sharpness_enhancer.enhance(1.5)

# show 
image.show()
enhanced_image.show()