from PIL import Image

# create an image via import
file_name = 'insect1.png'

image = Image.open('1_Gammar 2021_1_2021_06_03-13-19-23-879.PNG')
# analyze the image 
print(image.size)
print(image.filename)
print(image.format)
# show the image
image.show()

#  flip the image
image = image.transpose(Image.Transpose.ROTATE_90)

# # show the image 
image.show()

# exercise 
insect_rotated1 = image.rotate(30)
insect_rotated1.save('insect_rotated1', 'png')


file_name = 'insect2.png'

image = Image.open('1_Limniu 2021_1_2021_06_02-13-08-37-958.PNG')
# analyze the image 
print(image.size)
print(image.filename)
print(image.format)
# show the image
image.show()

#  flip the image
image = image.transpose(Image.Transpose.ROTATE_90)

# # show the image 
image.show()

# exercise 
insect_rotated2 = image.rotate(30)
insect_rotated2.save('insect_rotated2', 'png')


file_name = 'insect3.png'

image = Image.open('2_Sphaer 2021_1_2021_06_03-11-22-54-894.PNG')
# analyze the image 
print(image.size)
print(image.filename)
print(image.format)
# show the image
image.show()

#  flip the image
image = image.transpose(Image.Transpose.ROTATE_90)

# # show the image 
image.show()

# exercise 
insect_rotated3 = image.rotate(30)
insect_rotated3.save('insect_rotated3', 'png')